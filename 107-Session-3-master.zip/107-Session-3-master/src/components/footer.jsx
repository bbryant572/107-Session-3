import "./footer.css";

const Footer = () => {
    return (
        <div className ="footer">
            <h5>Dart Wizard Supplies. All rights reserved.</h5>
            <h6>Dev: Brett Bryant</h6>
        </div>
    );
}

export default Footer;
