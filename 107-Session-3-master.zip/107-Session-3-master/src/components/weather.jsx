

const Weather = () => {

    const loadData = () => {
        let location = new GeoLocation();


    }
    
    useEffect(() => {
        loadData();
    });

    return (


    )
};

export default Weather;