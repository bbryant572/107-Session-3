import "./cart.css"


const Cart = () => {

    return (
        <div className="cart">
            <h1>Your current Cart</h1>
        </div>

        
    );
}

export default Cart;