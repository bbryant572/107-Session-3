import "./quantityPicker.css";

const QuantityPicker = () => {
    return (
        <div className="quantity-picker">

            <button>+</button>

            <label>1</label>

            <button>-</button>

        </div>
    );
}

export default QuantityPicker;